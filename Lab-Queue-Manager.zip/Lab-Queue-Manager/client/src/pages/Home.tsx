import React, { useState, useRef } from 'react';
import { Search, RefreshCcw, ArrowUp, ChevronDown } from 'lucide-react';

// --- MOCK DATA ---
const MOCK_PATIENTS = [
  {
    id: "1",
    patient: { name: "Johnson, Emily", dob: "05/12/1978", age: "47y", gender: "Female" },
    status: { count: 4, label: "Unreviewed" },
    priority: "High Priority",
    testResults: ["Comprehensive Metabolic Panel", "Lipid Panel", "Complete Blood Count (CBC)", "+1 more"],
    criticalValues: [
      { type: "critical", label: "Glucose", value: "245" },
      { type: "abnormal", label: "BUN", value: "28" }
    ],
    resultDate: "10/24/2023 14:30",
    collectionDate: "10/24/2023 08:15",
    orderDate: "10/23/2023 16:00"
  },
  {
    id: "2",
    patient: { name: "Smith, Robert", dob: "11/04/1955", age: "68y", gender: "Male" },
    status: { count: 1, label: "Unreviewed" },
    priority: "High Priority",
    testResults: ["Troponin I", "Creatinine Kinase", "CBC"],
    criticalValues: [
      { type: "critical", label: "Troponin I", value: "0.85" }
    ],
    resultDate: "10/24/2023 15:10",
    collectionDate: "10/24/2023 09:30",
    orderDate: "10/24/2023 09:00"
  },
  {
    id: "3",
    patient: { name: "Williams, Sarah", dob: "02/18/1990", age: "33y", gender: "Female" },
    status: { count: 2, label: "Unreviewed" },
    priority: "Routine",
    testResults: ["TSH", "Vitamin D, 25-Hydroxy", "Iron, Total"],
    criticalValues: [
      { type: "abnormal", label: "Vitamin D", value: "18" }
    ],
    resultDate: "10/24/2023 11:45",
    collectionDate: "10/23/2023 10:00",
    orderDate: "10/22/2023 14:20"
  },
  {
    id: "4",
    patient: { name: "Davis, Michael", dob: "08/30/1962", age: "61y", gender: "Male" },
    status: { count: 1, label: "Unreviewed" },
    priority: "Routine",
    testResults: ["PSA, Total", "Basic Metabolic Panel"],
    criticalValues: [
      { type: "abnormal", label: "PSA", value: "5.8" },
      { type: "abnormal", label: "Creatinine", value: "1.5" }
    ],
    resultDate: "10/24/2023 09:20",
    collectionDate: "10/23/2023 08:45",
    orderDate: "10/20/2023 11:10"
  },
  {
    id: "5",
    patient: { name: "Martinez, Linda", dob: "04/22/1985", age: "38y", gender: "Female" },
    status: { count: 0, label: "Reviewed" },
    priority: "Routine",
    testResults: ["Urinalysis, Complete", "Urine Culture"],
    criticalValues: [],
    resultDate: "10/23/2023 16:50",
    collectionDate: "10/23/2023 14:20",
    orderDate: "10/23/2023 14:00"
  },
  {
    id: "6",
    patient: { name: "Brown, James", dob: "09/15/1945", age: "78y", gender: "Male" },
    status: { count: 3, label: "Unreviewed" },
    priority: "Routine",
    testResults: ["Prothrombin Time (PT)", "INR", "Hepatic Function Panel"],
    criticalValues: [
      { type: "abnormal", label: "INR", value: "3.2" }
    ],
    resultDate: "10/23/2023 15:30",
    collectionDate: "10/23/2023 07:45",
    orderDate: "10/21/2023 09:30"
  }
];

// --- SUBCOMPONENTS ---

const FilterSelect = ({ label, searchable = false, defaultValue = "" }: { label: string, searchable?: boolean, defaultValue?: string }) => (
  <div className="flex flex-col gap-0.5">
    <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider pl-1">{label}</label>
    <div className="relative">
      {searchable && <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400" size={12} />}
      <select
        className={`w-full bg-white border border-gray-300 rounded px-2 py-1 text-xs appearance-none focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 shadow-sm ${searchable ? 'pl-7' : ''}`}
        defaultValue={defaultValue}
      >
        <option value={defaultValue}>{defaultValue || `Select ${label}`}</option>
        <option value="opt1">Option 1</option>
        <option value="opt2">Option 2</option>
      </select>
      <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none" size={12} />
    </div>
  </div>
);

const FilterDate = ({ label }: { label: string }) => (
  <div className="flex flex-col gap-0.5">
    <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider pl-1">{label}</label>
    <input
      type="date"
      className="w-full bg-white border border-gray-300 rounded px-2 py-1 text-xs focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 shadow-sm"
    />
  </div>
);

const CheckboxLabel = ({ label }: { label: string }) => (
  <label className="flex items-center gap-2 text-xs text-gray-700 hover:text-gray-900 cursor-pointer">
    <input type="checkbox" className="rounded-sm border-gray-300 text-teal-600 focus:ring-teal-500 w-3.5 h-3.5" defaultChecked={true} />
    {label}
  </label>
);

const StatusSummary = () => (
  <div className="flex items-center gap-5 text-xs font-medium px-4 py-2 bg-white border-b border-gray-200 shrink-0">
    <div className="flex items-center gap-1.5 text-gray-700">
      <div className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-sm"></div> 2 Critical
    </div>
    <div className="flex items-center gap-1.5 text-gray-700">
      <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-sm"></div> 8 Abnormal
    </div>
    <div className="flex items-center gap-1.5 text-gray-700">
      <div className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-sm"></div> 12 Normal
    </div>
    <div className="text-gray-400 border-l border-gray-200 pl-4">22 Total Patients</div>
  </div>
);

// --- MAIN PAGE ---

export default function Home() {
  const [isFilterVisible, setIsFilterVisible] = useState(true);
  const [activeTab, setActiveTab] = useState("View All");
  const [isLoading, setIsLoading] = useState(false);
  
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const handleScrollUp = () => {
    scrollContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    setIsFilterVisible(false);
  };

  const handleRefresh = () => {
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 500);
  };

  const handleFilterToggle = () => {
    setIsFilterVisible(!isFilterVisible);
  };

  const TABS = ["View All", "View All Abnormal", "View Archived", "Other Letters", "After Care Dashboard"];

  const displayData = MOCK_PATIENTS.filter(p => {
    if (activeTab === "View All Abnormal") return p.criticalValues.length > 0;
    return true;
  });

  return (
    <div className="h-screen w-full flex flex-col bg-gray-200 overflow-hidden font-sans text-sm selection:bg-teal-100">
      
      {/* 1. TOP HEADER SECTION */}
      <header className="bg-[#006064] text-white px-4 py-2 flex items-center justify-between shadow-md z-20 shrink-0 border-b border-teal-900">
        <div className="flex flex-col">
          <h1 className="text-base font-bold leading-tight tracking-wide drop-shadow-sm">L-Jellybean Work Queue</h1>
          <h2 className="text-[10px] text-teal-100 font-bold uppercase tracking-wider opacity-90">Laboratory Procedures</h2>
        </div>
        <div className="flex items-center gap-4">
          {!isFilterVisible && (
            <button 
              onClick={handleFilterToggle}
              className="text-xs font-semibold bg-teal-800 hover:bg-teal-700 px-3 py-1 rounded transition-colors border border-teal-600"
            >
              Show Filters
            </button>
          )}
          <span className="bg-teal-900 text-white px-3.5 py-0.5 rounded-full text-sm font-bold shadow-inner border border-teal-800" title="Total Items">
            128
          </span>
        </div>
      </header>

      {/* 2 & 3 & 4. FILTER PANEL */}
      {isFilterVisible && (
        <div className="bg-[#f0f2f5] p-3 border-b border-gray-300 shadow-sm shrink-0 transition-all">
          <div className="flex gap-4 items-stretch">
            
            {/* Left: Dropdowns Grid */}
            <div className="grid grid-cols-3 gap-x-4 gap-y-2 flex-1">
              {/* Row 1 */}
              <FilterSelect label="Provider" searchable defaultValue="Dr. Adams" />
              <FilterSelect label="Lab Order" searchable defaultValue="All Orders" />
              <FilterSelect label="Filter By" defaultValue="Order Date" />
              
              {/* Row 2 */}
              <FilterSelect label="Facility" defaultValue="All Facilities" />
              <FilterSelect label="DI Order" searchable defaultValue="" />
              <FilterDate label="Date From" />
              
              {/* Row 3 */}
              <FilterSelect label="Assign To" defaultValue="Me" />
              <FilterSelect label="Procedure Order" searchable defaultValue="" />
              <FilterDate label="Date To" />
            </div>

            {/* Middle: Checkboxes */}
            <div className="flex gap-6 px-6 border-l border-gray-300 py-1">
              <div className="flex flex-col justify-center gap-1.5">
                <CheckboxLabel label="Labs" />
                <CheckboxLabel label="Imaging" />
                <CheckboxLabel label="Procedures" />
              </div>
              <div className="flex flex-col justify-center gap-1.5">
                <CheckboxLabel label="In-House" />
                <CheckboxLabel label="Send-Out" />
                <CheckboxLabel label="High Priority" />
              </div>
            </div>

            {/* Right: Buttons */}
            <div className="flex flex-col justify-end gap-2 pl-4 border-l border-gray-300 min-w-[120px]">
              <div className="flex items-center justify-end gap-2 mt-auto">
                <button 
                  onClick={handleRefresh}
                  className="bg-teal-600 hover:bg-teal-700 text-white font-bold px-5 py-1.5 rounded shadow-sm text-xs transition-colors focus:ring-2 focus:ring-teal-500 focus:outline-none"
                >
                  Filter
                </button>
                <button 
                  onClick={handleRefresh}
                  className={`bg-white hover:bg-gray-50 border border-gray-300 p-1.5 rounded shadow-sm text-gray-600 transition-all ${isLoading ? 'animate-spin' : ''}`}
                  title="Refresh Data"
                >
                  <RefreshCcw size={14} />
                </button>
                <button 
                  onClick={handleScrollUp}
                  className="bg-white hover:bg-gray-50 border border-gray-300 p-1.5 rounded shadow-sm text-gray-600 transition-colors"
                  title="Scroll Up & Hide Filters"
                >
                  <ArrowUp size={14} />
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* 5. STATUS SUMMARY */}
      <StatusSummary />

      {/* 6. NAVIGATION TABS */}
      <div className="flex gap-1.5 px-3 py-2 bg-gray-100 border-b border-gray-300 shrink-0 overflow-x-auto hide-scrollbar">
        {TABS.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-1.5 rounded text-[11px] font-semibold transition-all whitespace-nowrap ${
              activeTab === tab 
                ? 'bg-[#006064] text-white shadow-md' 
                : 'bg-white text-gray-600 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* 7 & 8 & 9 & 10 & 11. ORDERS TABLE */}
      <div className="flex-1 bg-white overflow-auto relative" ref={scrollContainerRef}>
        <table className="w-full text-left border-collapse min-w-[1000px]">
          <thead className="sticky top-0 z-10 bg-[#f8f9fa] shadow-[0_1px_0_rgba(0,0,0,0.1)]">
            <tr>
              <th className="px-2 py-1.5 w-8 text-center"><input type="checkbox" className="rounded-sm border-gray-300 text-teal-600" /></th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300">Action</th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300">Status</th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300">Priority</th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300 w-[180px]">Patient Name / Details</th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300 w-[220px]">Test Results</th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300 w-[180px]">Critical / Abnormal</th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300">Result Date</th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300">Collection Date</th>
              <th className="px-2 py-1.5 text-[11px] font-bold text-gray-700 uppercase tracking-wider border-b border-gray-300">Order Date</th>
            </tr>
          </thead>
          <tbody className={`divide-y divide-gray-100 ${isLoading ? 'opacity-50 pointer-events-none' : ''}`}>
            {displayData.map((patient) => (
              <tr key={patient.id} className="hover:bg-[#f0f9fa] transition-colors group">
                <td className="px-2 py-2 align-top text-center border-r border-gray-50/50">
                  <input type="checkbox" className="rounded-sm border-gray-300 text-teal-600 focus:ring-teal-500 mt-1" />
                </td>
                <td className="px-2 py-2 align-top border-r border-gray-50/50">
                  <button className="bg-blue-50 text-blue-700 border border-blue-200 px-3 py-0.5 rounded-full text-[10px] font-bold hover:bg-blue-100 transition-colors shadow-sm">
                    Review
                  </button>
                </td>
                <td className="px-2 py-2 align-top border-r border-gray-50/50">
                  <span className={`inline-block border px-1.5 py-0.5 rounded text-[10px] font-medium ${patient.status.count > 0 ? 'bg-gray-100 border-gray-300 text-gray-800' : 'bg-green-50 border-green-200 text-green-700'}`}>
                    {patient.status.count} {patient.status.label}
                  </span>
                </td>
                <td className="px-2 py-2 align-top border-r border-gray-50/50">
                  {patient.priority === 'High Priority' ? (
                    <span className="inline-block bg-red-50 text-red-700 border border-red-200 px-1.5 py-0.5 rounded text-[10px] font-bold tracking-wide">
                      {patient.priority}
                    </span>
                  ) : (
                    <span className="inline-block bg-gray-50 text-gray-500 border border-gray-200 px-1.5 py-0.5 rounded text-[10px] font-medium">
                      {patient.priority}
                    </span>
                  )}
                </td>
                <td className="px-2 py-2 align-top border-r border-gray-50/50">
                  <div className="font-bold text-gray-900 text-xs">{patient.patient.name}</div>
                  <div className="text-gray-500 text-[11px] mt-0.5">{patient.patient.dob}</div>
                  <div className="text-gray-500 text-[11px]">{patient.patient.age} / {patient.patient.gender}</div>
                </td>
                <td className="px-2 py-2 align-top text-gray-700 text-[11px] leading-snug border-r border-gray-50/50">
                  {patient.testResults.map((res, idx) => (
                    <div key={idx} className={res.startsWith('+') ? "text-teal-700 font-bold mt-1" : "truncate"}>
                      {res}
                    </div>
                  ))}
                </td>
                <td className="px-2 py-2 align-top border-r border-gray-50/50">
                  <div className="flex flex-col gap-1 items-start">
                    {patient.criticalValues.map((cv, idx) => (
                      <span key={idx} className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border shadow-sm ${
                        cv.type === 'critical' 
                          ? 'bg-red-50 text-red-800 border-red-200' 
                          : 'bg-orange-50 text-orange-800 border-orange-200'
                      }`}>
                        {cv.type === 'critical' && <span className="font-bold mr-1">CRIT:</span>}
                        {!cv.type.includes('critical') && <span className="font-semibold mr-1">ABN:</span>}
                        {cv.label} <span className="ml-1 opacity-80">{cv.value}</span>
                      </span>
                    ))}
                    {patient.criticalValues.length === 0 && (
                      <span className="text-[10px] text-gray-400 italic">None</span>
                    )}
                  </div>
                </td>
                <td className="px-2 py-2 align-top text-gray-600 text-[11px] whitespace-nowrap">{patient.resultDate}</td>
                <td className="px-2 py-2 align-top text-gray-500 text-[11px] whitespace-nowrap">{patient.collectionDate}</td>
                <td className="px-2 py-2 align-top text-gray-400 text-[11px] whitespace-nowrap">{patient.orderDate}</td>
              </tr>
            ))}
            
            {/* Empty state padding for realism */}
            {displayData.length === 0 && (
              <tr>
                <td colSpan={10} className="px-4 py-8 text-center text-gray-500 text-sm">
                  No records found for current filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
    </div>
  );
}
